//
//  ViewController.swift
//  AnimationsDemo
//
//  Created by Chitrala,Bhanuteja on 4/9/23.
//

import UIKit

class ViewController: UIViewController {

   
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    @IBOutlet weak var happyOutlet: UIButton!
    
    
    @IBOutlet weak var sadOutlet: UIButton!
    
    
    @IBOutlet weak var shakeMeOutlet: UIButton!
    
    @IBOutlet weak var angryOutlet: UIButton!
    
    
    @IBOutlet weak var showOutlet: UIButton!
    
    @IBAction func happyButton(_ sender: Any) {
        animateImage(imageName: "happy")
    }
    
    
    @IBAction func sadButton(_ sender: Any) {
        animateImage(imageName: "sad")
    }
    
   
    @IBAction func angryButton(_ sender: Any) {
        animateImage(imageName: "angry")
    }
    
    
    @IBAction func shakeMeButton(_ sender: Any) {
        var width = self.imageViewOutlet.frame.width+50
        var height = self.imageViewOutlet.frame.height+50
        var x=self.imageViewOutlet.frame.origin.x-20
        var y=self.imageViewOutlet.frame.origin.y-20
        
        var newFrame=CGRect(x: x, y: y, width: width, height: height)
        
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.2, initialSpringVelocity: 50, animations: {
            self.imageViewOutlet.frame=newFrame
        })
    }
    
    
    @IBAction func showButton(_ sender: Any) {
        UIView.animate(withDuration: 1, animations: {
                    //Move all the compoenets to the center and disable show button
                    self.imageViewOutlet.center.x = self.view.center.x
                    
                    self.happyOutlet.center.x = self.view.center.x;
                    
                    self.sadOutlet.center.x = self.view.center.x;
                    
                    self.angryOutlet.center.x = self.view.center.x;
                    
                    self.shakeMeOutlet.center.x = self.view.center.x
                    
                })
                
                showOutlet.isEnabled = false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
            //Move the image view outside of the screen view.
            imageViewOutlet.frame.origin.x = view.frame.maxX
            
            //Similarly, move other components as well outside of the screen
            
            happyOutlet.frame.origin.x = view.frame.width
            
            sadOutlet.frame.origin.x = view.frame.width
            
            angryOutlet.frame.origin.x = view.frame.width
            
            shakeMeOutlet.frame.origin.x = view.frame.width
        }
    
    func animateImage(imageName:String){
        UIView.animate(withDuration: 1, animations:{
            self.imageViewOutlet.alpha=0
        })
        
        UIView.animate(withDuration: 1, delay: 0.6, animations: {
            self.imageViewOutlet.alpha=1
            self.imageViewOutlet.image=UIImage(named: imageName)
        })
    }

}

