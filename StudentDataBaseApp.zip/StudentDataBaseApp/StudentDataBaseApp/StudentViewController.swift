//
//  StudentViewController.swift
//  StudentDataBaseApp
//
//  Created by Chitrala,Bhanuteja on 4/4/23.
//

import UIKit

class StudentViewController: UIViewController {

    
    
    @IBOutlet weak var nameOutlet: UILabel!
    
    
    @IBOutlet weak var sidOutlet: UILabel!
    
    
    
    @IBOutlet weak var emailOutlet: UILabel!
    
    
    
    var studentInfo = Student()
    
    var guestUser = false
    
    
    
    @IBAction func courseInfo(_ sender: UIButton) {
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
            
        if guestUser{
            nameOutlet.text="Name : Guest User"
        }else{
            nameOutlet.text="Name : "+studentInfo.name
            sidOutlet.text="SID : "+studentInfo.sid
            emailOutlet.text="Email : "+studentInfo.email
            
        }
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
