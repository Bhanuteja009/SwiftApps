//
//  ViewController.swift
//  StudentDataBaseApp
//
//  Created by Chitrala,Bhanuteja on 4/4/23.
//

import UIKit

class LoginViewController: UIViewController {

   
    
    @IBOutlet weak var idOutlet: UITextField!
    
    var student=Student()
    
    var studentsDetails = students
    
    var isStudent = false
   
    @IBAction func studentInfo(_ sender: UIButton) {
        var sid = idOutlet.text!
        
        for stu in studentsDetails{
            
            if sid == stu.sid{
                student = stu
                
                isStudent = true
            }
        }
        
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var trans = segue.identifier
        
        if trans == "studentSegue"{
            var des = segue.destination as! StudentViewController
            
            if isStudent{
                des.studentInfo=student
            }else{
                des.guestUser=true
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

