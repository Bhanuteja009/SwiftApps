//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Chitrala,Bhanuteja on 3/16/23.
//

import UIKit

class ViewController: UIViewController {

   
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var courseNumOutlet: UILabel!
    
    
    @IBOutlet weak var courseNameOutlet: UILabel!
    
    
    @IBOutlet weak var semOutelt: UILabel!
   
    
    @IBOutlet weak var preOutlet: UIButton!
    
    
    @IBOutlet weak var nextOutlet: UIButton!
    
    var imgNum=0
    
    let courses = [["img01","44555","Network Security","Fall 2022"],
                   ["img02","44643","IOS","Spring 2023"],
                   ["img03","44656","Streaming Data","Fall 2024"]]
    
    
    @IBAction func preAction(_ sender: UIButton) {
        
        imgNum-=1
        //update next course details
        updateCourseDetails(_imgNum: imgNum)
        //enable next button
        
        nextOutlet.isEnabled=true
        //disable previous button when we reach final index
       
        if(imgNum==0){
            preOutlet.isEnabled=false
        }
        
    }
    
    
    @IBAction func nextAction(_ sender: UIButton) {
        
        imgNum+=1
        //update next course details
       
        updateCourseDetails(_imgNum: imgNum)
        //enable pre button
        
        preOutlet.isEnabled=true
        //disable next button when we reach final index
       
        if(imgNum==courses.count-1){
            nextOutlet.isEnabled=false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        // load details  at 0th index
        
        updateCourseDetails(_imgNum: 0)
        
        // disable previous button
        
        preOutlet.isEnabled=false
        // enable next button
        nextOutlet.isEnabled=true
    }

    func updateCourseDetails(_imgNum:Int){
        displayImage.image=UIImage(named: courses[imgNum][0])
        
        courseNumOutlet.text=courses[imgNum][1]
        
        courseNameOutlet.text=courses[imgNum][2]
        
        semOutelt.text=courses[imgNum][3]
    }

}

