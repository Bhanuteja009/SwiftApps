//
//  ViewController.swift
//  CoordinatesDemo
//
//  Created by Chitrala,Bhanuteja on 3/23/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var imageView: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let minX=imageView.frame.minX
        
        let minY=imageView.frame.minY
        
        print("[\(minX),\(minY)]")
        
        let maxX=imageView.frame.maxX
        
        let maxY=imageView.frame.maxY
        
        print("[\(maxX),\(maxY)]")
        
        let midX=imageView.frame.midX
        
        let midY=imageView.frame.midY
        
        print("[\(midX),\(midY)]")
        
        
        //moving image view to upper left corner
        
        imageView.frame.origin.x=0
        imageView.frame.origin.y=0
        
        
        //moving image view to upper right corner
        imageView.frame.origin.x=314
        imageView.frame.origin.y=0
        
        
        
        //moving image view to bottom left corner
        imageView.frame.origin.x=0
        imageView.frame.origin.y=796
        
        
        //moving image view to bottom right corner
        imageView.frame.origin.x=314
        imageView.frame.origin.y=796
        
        
        //moving image view to mid point of screen
        imageView.frame.origin.x=157
        imageView.frame.origin.y=348
    }


}

