//
//  ViewController.swift
//  SampleCalculator
//
//  Created by Chitrala,Bhanuteja on 2/2/23.
//

import UIKit

class ViewController: UIViewController {

    var oper1:Double = -1
    var oper:Character = " "
    var oper2:Double = -1
    
    @IBOutlet weak var displayOutlet: UILabel!
    
    
    @IBAction func button5Clicked(_ sender: UIButton) {
        
        displayOutlet.text="5"
        if oper1 == -1{
            oper1=5
        }
        else{
            oper2 = 5
        }
    }
    
    @IBAction func button3Clicked(_ sender: UIButton) {
        displayOutlet.text="3"
        
        if oper2 == -1{
            oper2=3
        }
        else{
            oper1 = 3
        }
    }
    
    @IBAction func buttonplusClicked(_ sender: UIButton) {
        displayOutlet.text="+"
        if oper == " "{
            oper="+"
        }
    }
    
    
    @IBAction func buttonminusClicked(_ sender: UIButton) {
        displayOutlet.text="-"
        if oper == " "{
            oper="-"
        }
    }
    
    @IBAction func buttonEqualsClicked(_ sender: UIButton) {
        displayOutlet.text="="
        switch oper{
        case "+" :
            displayOutlet.text="\(oper1+oper2)"
            
        case "-" :
            displayOutlet.text="\(oper1-oper2)"
            
        default:
            print("no operation")
     
        
       }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

