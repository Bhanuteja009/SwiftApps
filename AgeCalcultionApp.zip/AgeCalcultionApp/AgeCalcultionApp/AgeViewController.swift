//
//  AgeViewController.swift
//  AgeCalcultionApp
//
//  Created by Chitrala,Bhanuteja on 4/3/23.
//

import UIKit

class AgeViewController: UIViewController {

    
    
    @IBOutlet weak var nameLabel: UILabel!
    
    
    @IBOutlet weak var yearLabel: UILabel!
    
    
    @IBOutlet weak var ageLabel: UILabel!
    
    
    var name = ""
    var year = ""
    var age = 0
    
    
    @IBAction func clickHere(_ sender: Any) {
        
        nameLabel.text! = "Name : "+name
        yearLabel.text! = "Birth year : "+year
        ageLabel.text! = " Age : \(age)"
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
