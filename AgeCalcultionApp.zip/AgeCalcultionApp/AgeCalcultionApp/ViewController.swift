//
//  ViewController.swift
//  AgeCalcultionApp
//
//  Created by Chitrala,Bhanuteja on 4/3/23.
//

import UIKit

class ViewController: UIViewController {

   
    @IBOutlet weak var nameOL: UITextField!
    
    
    @IBOutlet weak var yearOL: UITextField!
    
    var currentYear = Calendar.current.component(.year, from: Date())
    
    var age = 0
    
    @IBAction func calculateAge(_ sender: UIButton) {
    
        var name = nameOL.text!
        var birthYear = yearOL.text!
        
        age = currentYear - Int(birthYear)!
    
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var abc = segue.identifier
        if abc == "ResultSegue"{
            var des = segue.destination as! AgeViewController
            des.name = nameOL.text!
            des.year = yearOL.text!
            des.age = age
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

