//
//  ViewController.swift
//  BMIApp
//
//  Created by Chitrala,Bhanuteja on 4/10/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var heightOL: UITextField!
    
    
    @IBOutlet weak var weightOL: UITextField!
    
    var bmiValue=0.0
    
    @IBAction func calculate(_ sender: Any) {
        
        var height=Double(heightOL.text!)
        
        var weight=Double(weightOL.text!)
        
        bmiValue=round((weight!/(height!*height!))*100)/100
    }
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var trans=segue.identifier
        if trans=="BMISegue"{
            
            var des=segue.destination as! BMIViewController
            des.bmiVal=bmiValue
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

