//
//  AnimateViewController.swift
//  BMIApp
//
//  Created by Chitrala,Bhanuteja on 4/10/23.
//

import UIKit

class AnimateViewController: UIViewController {

    
    
    @IBOutlet weak var animateImageOL: UIImageView!
    
   
    var imageName=""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        animateImageOL.image=UIImage(named: imageName)
        var height=animateImageOL.frame.height+60
        var width=animateImageOL.frame.width+50
        var x=animateImageOL.frame.origin.x+20
        var y=animateImageOL.frame.origin.y+20
        
        var newFrame=CGRect(x: x, y: y, width: width, height: height)
        
        UIView.animate(withDuration: 1, delay: 0.6, usingSpringWithDamping: 0.2, initialSpringVelocity: 60, animations: {
            self.animateImageOL.frame=newFrame
        })

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
