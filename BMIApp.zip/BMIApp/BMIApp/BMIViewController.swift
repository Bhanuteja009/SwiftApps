//
//  BMIViewController.swift
//  BMIApp
//
//  Created by Chitrala,Bhanuteja on 4/10/23.
//

import UIKit

class BMIViewController: UIViewController {

   
    @IBOutlet weak var bmiValueLabel: UILabel!
    
    
    @IBOutlet weak var imageOL: UIImageView!
   
    
    @IBAction func animate(_ sender: Any) {
    }
    
    
    var bmiVal=0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        bmiValueLabel.text!+="\(bmiVal)"
        imageOL.image=UIImage(named: "bmi")

        // Do any additional setup after loading the view.
    }
    

    @IBAction func animateMe(_ sender: Any) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var trans=segue.identifier
        if trans=="AnimateSegue"{
            var des=segue.destination as! AnimateViewController
            des.imageName="bmi"
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
