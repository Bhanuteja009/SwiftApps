//
//  ViewController.swift
//  DiscountAppMVC
//
//  Created by Chitrala,Bhanuteja on 3/30/23.
//

import UIKit

class ViewController: UIViewController {

    var priceAfterDiscount = 0.0
    
    @IBOutlet weak var amountOL: UITextField!
    
    
    @IBOutlet weak var discountRateOL: UITextField!
    
   
    @IBAction func calculatePriceAfterDisc(_ sender: Any) {
        var amt=Double(amountOL.text!)
        var discRate=Double(discountRateOL.text!)
        
        priceAfterDiscount = amt! - (amt!*discRate!)/100
        print(amt!,discRate!,priceAfterDiscount)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "resultSegue"{
            var destination = segue.destination as! ResultViewController
            destination.amt = amountOL.text!
            destination.discount = discountRateOL.text!
            destination.priceAfterDisc = "\(priceAfterDiscount)"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

